public class BaseClass {
    public BaseClass() {
    }

}
