public class OtherDerivedClass extends BaseClass {
}
